import React from "react";
import ConfigurationForm from "./components/configuration/ConfigurationForm";
//import "./styles/ConfigurationForm.css";
import Header from "./components/header/Header";
//import "./styles/Header.css";
import CustomerVendorManagement from "./components/customer-vendor-management/CustomerVendorManagement";
//import "./styles/CustomerVendorManagement.css";
import ProgressBar from "./components/progress-bar/ProgressBar";
import TransactionLog from "./components/transaction-log/TransactionLog";
//import "./styles/TransactionLog.css";
import StartStopSystem from "./components/start-stop-system/StartStopSystem";
import Console from "./components/console/Console";
import "./app.css";

const App = () => {
  return (
    <div className="App flex-col">
      <Header className="flex-row">
        <StartStopSystem />
      </Header>
      
      <div className="flex-row">
        <div className="flex-row">
          <CustomerVendorManagement />
          <ProgressBar />
          <Console />
        </div>
        <div className="flex-col">
          <ConfigurationForm />
        </div>
      </div>

    </div>
  );
};

export default App;
