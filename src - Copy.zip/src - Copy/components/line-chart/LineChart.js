import React, {useState, useEffect} from "react";
import {Line} from "react-chartjs-2";
import { Chart, registerables } from "chart.js";
import "./LineChart.css";

Chart.register(...registerables);

const Linechart = () => {
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: "Ticket Sales Over Time",
        data: [],
        borderColor: "rgba(75,192,192,1)",
        fill: false,
      },
    ],
  });

  useEffect(() => {
    fetch("http://localhost:8080/ticketing-system/api/chart/sales-data")
      .then((response) => response.json())
      .then((data) => {
        const labels = data.map((item) =>
          new Date(item.timestamp).toLocaleTimeString()
        );
        const tickets = data.map((item) => item.tickets);

        setChartData((prevState) => ({
          ...prevState,
          labels,
          datasets: [
            {
              ...prevState.datasets[0],
              data: tickets,
            },
          ],
        }));
      });

    const socket = new WebSocket("http://localhost:8080/ticketing-system/ws");

    socket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      const log = message.log;
      if (log.includes("bought")) {
        const timestamp = new Date().toLocaleTimeString();
        const remainingTickets = message.currentTickets;

        setChartData((prevState) => ({
          ...prevState,
          labels: [...prevState.labels, timestamp],
          datasets: [
            {
              ...prevState.datasets[0],
              data: [...prevState.datasets[0].data, remainingTickets],
            },
          ],
        }));
      }
    };

    return () => socket.close();
  }, []);

  return (
    <div className="chart-container">
      <h2>Real-Time Ticket Sales</h2>
      <Line
        data={chartData}
        options={{
          responsive: true,
          plugins: {
            legend: {
              position: "top",
            },
          },
          scales: {
            x: {
              title: {
                display: true,
                text: "Time",
              },
            },
            y: {
              title: {
                display: true,
                text: "Tickets Remaining",
              },
            },
          },
        }}
      />
    </div>
  );
};

export default Linechart