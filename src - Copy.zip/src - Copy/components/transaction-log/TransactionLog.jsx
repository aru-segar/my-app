import React, { useEffect, useState } from 'react';
import "./TransactionLog.css";

const TransactionLog = () => {
    const [messages, setMessages] = useState([]);
    const [socket, setSocket] = useState(null); // Use socket state to store WebSocket instance

    // Establish WebSocket connection
    useEffect(() => {
        const ws = new WebSocket('http://localhost:8080/ticketing-system/ws'); // Corrected WebSocket URL

        // Listen for messages from the server
        ws.onmessage = (event) => {
            const message = JSON.parse(event.data);
            setMessages((prevMessages) => [...prevMessages, { ...message, timestamp: new Date().toLocaleTimeString() }]);
        };

        ws.onopen = () => {
            console.log("WebSocket connected");
        };

        ws.onerror = (error) => {
            console.log("WebSocket error", error);
        };

        ws.onclose = () => {
            console.log("WebSocket connection closed");
        };

        // Store the WebSocket instance in state
        setSocket(ws);

        // Cleanup WebSocket connection on component unmount
        return () => {
            if (ws) {
                ws.close();
            }
        };
    }, []);

    // Scroll to the bottom of the log container whenever a new message is added
    useEffect(() => {
        const logContainer = document.getElementById('logContainer');
        if (logContainer) {
            logContainer.scrollTop = logContainer.scrollHeight;
        }
    }, [messages]);

    // Optionally: Send a message to the WebSocket server (example)
    const sendMessage = (msg) => {
        if (socket && socket.readyState === WebSocket.OPEN) {
            socket.send(msg);
            console.log('Message sent:', msg);
        }
    };

    return (
        <div>
            <h2>Transaction Messages</h2>
            <div
                id="logContainer"
                style={{
                    border: '1px solid #ccc',
                    padding: '10px',
                    height: '300px',
                    overflowY: 'scroll',
                    marginTop: '20px',
                    borderRadius: '5px',
                    backgroundColor: '#f9f9f9',
                    fontFamily: 'monospace',
                }}
            >
                {messages.length === 0 ? (
                    <p>No transaction logs yet...</p>
                ) : (
                    messages.map((message, index) => (
                        <div key={index} style={{ padding: '5px', marginBottom: '10px', borderBottom: '1px solid #ddd' }}>
                            <p>
                                <strong>{message.timestamp}</strong> - {message.status}: {message.message}
                            </p>
                            {message.details && <pre>{JSON.stringify(message.details, null, 2)}</pre>}
                        </div>
                    ))
                )}
            </div>

            {/* Example Button to send a message to the WebSocket server */}
            <button onClick={() => sendMessage('Hello from client!')}>Send Message</button>
        </div>
    );
};

export default TransactionLog;

